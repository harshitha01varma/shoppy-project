// import React, { Suspense, lazy } from 'react';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Header from './Components/Header';
// import NotFound from './Components/NotFound';
// import Product from './styles/Product.jsx';


// import './App.css';

// const ProductList = lazy(() => import('./Components/ProductList'));
// const ProductDetail = lazy(() => import('./Components/ProductDetail'));
// const Cart = lazy(() => import('./Components/Cart'));

// function App() {
//   return (
//     <Router>
//       <Header />
//       <Suspense fallback={<div>Loading...</div>}>
//         <Routes>
//           <Route path="/" element={<ProductList />} />
//           <Route path="/product/:id" element={<ProductDetail />} />
//           <Route path="/cart" element={<Cart />} />
//           <Route path="*" element={<NotFound />} />
//         </Routes>
//       </Suspense>
//     </Router>
//   );
// }

// export default App;

import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './Components/Header';
import NotFound from './Components/NotFound';
import './App.css';

// Lazy loaded components
const ProductList = lazy(() => import('./Components/ProductList'));
const ProductDetail = lazy(() => import('./Components/ProductDetail'));
const Cart = lazy(() => import('./Components/Cart'));

// ✅ Import your new Products page (not lazy-loaded unless you want to)
import ProductsPage from './pages/ProductsPage';

function App() {
  return (
    <Router>
      <Header />
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<ProductList />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/products" element={<ProductsPage />} /> {/* ✅ Add this line */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </Router>
  );
}

export default App;
