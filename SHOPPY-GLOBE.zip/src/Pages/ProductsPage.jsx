// import React from 'react';
// import ProductCard from '../Components/ProductCard'; // Adjust the path as needed
// import useProducts from '../hooks/useProducts'; // Your custom hook
// import '../styles/products.css'; // Your CSS file for grid

// const ProductsPage = () => {
//   const products = useProducts();

//   return (
//     <div className="product-page">
//       <h2>All Products</h2>
//       <div className="product-grid">
//         {products.map(product => (
//           <ProductCard key={product.id} product={product} />
//         ))}
//       </div>
//     </div>
//   );
// };

// export default ProductsPage;
import React from 'react';
import useProducts from '../hooks/useProducts';
import ProductCard from '../Components/ProductCard';
import '../styles/products.css';

const ProductsPage = () => {
  const data = useProducts();
  const products = Array.isArray(data) ? data : data?.products || [];

  return (
    <div className="product-page">
      <h2>All Products</h2>
      <div className="product-grid">
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductsPage;
