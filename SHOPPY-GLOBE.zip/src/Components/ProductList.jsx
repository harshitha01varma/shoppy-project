import React from 'react';
import useProducts from '../hooks/useProducts';

import ProductCard from './ProductCard';

import '../Components/ProductList.css';

const ProductList = () => {
  const { products, error } = useProducts();

  if (error) return <p>Error: {error}</p>;

  return (
    <div className="product-list">
      {products.map(product => (
        <ProductCard key={product.id} product={product} />


      ))}
    </div>
  );
};

export default ProductList;




// productlist.jsx
// import React from 'react';
// import useProducts from '../hooks/useProducts';
// import ProductCard from './ProductCard'; // ✅ use ProductCard instead of ProductItem
// import '../Components/ProductList.css';

// const ProductList = () => {
//   const { products, error } = useProducts();

//   if (error) return <p>Error: {error}</p>;

//   return (
//     <div className="product-list">
//       {products.map(product => (
//         <ProductCard key={product.id} product={product} /> // ✅ this must be ProductCard
//       ))}
//     </div>
//   );
// };

// export default ProductList;

// import React from "react";
// import { useDispatch } from "react-redux";
// import { addToCart } from "../redux/cartSlice";

// const ProductCard = ({ product }) => {
//   const dispatch = useDispatch();

//   const handleAddToCart = () => {
//     console.log("Adding to cart:", product); // ✅ This should now work
//     dispatch(addToCart(product));
//   };

//   return (
//     <div className="product-card">
//       <img src={product.thumbnail} alt={product.title} />
//       <h3>{product.title}</h3>
//       <p>₹{product.price}</p>
//       <button onClick={handleAddToCart}>Add to Cart</button>
//     </div>
//   );
// };

// export default ProductCard;
