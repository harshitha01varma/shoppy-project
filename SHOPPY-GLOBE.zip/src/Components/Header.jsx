// import React from 'react';
// import { Link } from 'react-router-dom';
// import '../styles/header.css'; 
// import { useSelector } from 'react-redux';


// const cartItems = useSelector(state => state.cart.items);
// const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

// const Header = () => {
//   return (
//     <header className="shoppy">
      
//       <nav className="navLinks">
//         <Link to="/">Home</Link>
//         <Link to="/products">Products</Link>
//         <Link to="/cart">Cart</Link>
//         <Link to="/cart" className="cart-link">
//   🛒 Cart ({cartCount})
// </Link>

//         <Link to="/checkout">Checkout</Link>
//       </nav>
//       <h1>SHOPPY GLOBE</h1>
//     </header>
//   );
// };
// export default Header;











import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/header.css';
import { useSelector } from 'react-redux';

const Header = () => {
  // ✅ Move hooks inside the component
  const cartItems = useSelector(state => state.cart.items);
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="shoppy">
      <nav className="navLinks">
        <Link to="/">Home</Link>
        <Link to="/products">Products</Link>
        
        {/* 🛒 Updated cart link with count */}
        <Link to="/cart" className="cart-link">
          🛒 Cart ({cartCount})
        </Link>

        <Link to="/checkout">Checkout</Link>
      </nav>
      <h1>SHOPPY GLOBE</h1>
    </header>
  );
};

export default Header;
