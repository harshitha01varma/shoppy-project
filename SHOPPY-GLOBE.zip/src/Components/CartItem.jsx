// import React from "react";
// import { useDispatch } from "react-redux";
// import { addToCart, removeFromCart, decrementQty, incrementQty } from "../redux/cartSlice";

// incrementQty: (state, action) => {
//   const item = state.find((item) => item.id === action.payload);
//   if (item) {
//     item.quantity++;
//   }
// }



// const CartItem = ({ item }) => {
//   const dispatch = useDispatch();

//   const handleRemove = () => {
//     dispatch(removeFromCart(item.id));
//   };

//   const increaseQty = () => {
//     dispatch(incrementQty(item.id));
//   };

//   const decreaseQty = () => {
//     dispatch(decrementQty(item.id));
//   };

//   return (
//     <div className="cart-item">
//       <img src={item.thumbnail} alt={item.title} />
//       <div className="item-info">
//         <h3>{item.title}</h3>
//         <p>Price: ₹{item.price}</p>
//         <p>Quantity: {item.quantity}</p>
//         <p>Total: ₹{item.price * item.quantity}</p>
//         <div className="buttons">
//           <button onClick={increaseQty}>+</button>
//           <button onClick={decreaseQty} disabled={item.quantity === 1}>-</button>
//           <button className="remove-btn" onClick={handleRemove}>Remove</button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CartItem;
import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
  name: "cart",
  initialState: [],
  reducers: {
    addToCart: (state, action) => {
      const item = state.find((item) => item.id === action.payload.id);
      if (item) {
        item.quantity += 1;
      } else {
        state.push({ ...action.payload, quantity: 1 });
      }
    },
    removeFromCart: (state, action) => {
      return state.filter((item) => item.id !== action.payload);
    },
    decrementQty: (state, action) => {
      const item = state.find((item) => item.id === action.payload);
      if (item && item.quantity > 1) {
        item.quantity--;
      }
    },
    incrementQty: (state, action) => {
      const item = state.find((item) => item.id === action.payload);
      if (item) {
        item.quantity++;
      }
    },
  },
});

export const {
  addToCart,
  removeFromCart,
  decrementQty,
  incrementQty,
} = cartSlice.actions;

export default cartSlice.reducer;
