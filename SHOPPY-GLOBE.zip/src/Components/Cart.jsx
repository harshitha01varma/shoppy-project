// import React from "react";
// import { useSelector } from "react-redux";
// import CartItem from "./CartItem";
// import '../Components/Cart.css';

// const Cart = () => {
//   const cartItems = useSelector((state) => state.cart.items);

//   const totalPrice = Array.isArray(cartItems)
//   ? cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0)
//   : 0;

//   return (
//     <div className="cart-container">
//       <h2>Your Shopping Cart</h2>

//       {cartItems.length === 0 ? (
//         <p>Your cart is empty.</p>
//       ) : (
//         <>
//           <div className="cart-items">
//             {cartItems.map((item) => (
//               <CartItem key={item.id} item={item} />
//             ))}
//           </div>
//           <div className="cart-summary">
//             <h3>Total: ₹{totalPrice.toFixed(2)}</h3>
//             <button className="checkout-btn">Proceed to Checkout</button>
//           </div>
//         </>
//       )}
//     </div>
//   );
// };

// export default Cart;
// import React from "react";
// import { useSelector } from "react-redux";
// import CartItem from "./CartItem";

// const Cart = () => {
//   const cart = useSelector((state) => state.cart);

//   // Defensive checks to avoid undefined issues
//   if (!cart || !Array.isArray(cart)) {
//     return <p>Loading cart...</p>;
//   }

//   const totalPrice = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

//   return (
//     <div className="cart-container">
//       <h2>Your Cart</h2>
//       {cart.length === 0 ? (
//         <p>Your cart is empty.</p>
//       ) : (
//         <div>
//           {cart.map((item) => (
//             <CartItem key={item.id} item={item} />
//           ))}
//           <h3>Total Price: ₹{totalPrice}</h3>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Cart;




// import React from "react";
// import { useSelector } from "react-redux";
// import CartItem from "./CartItem";
// import "../Components/Cart.css"; 

// const Cart = () => {
  
//   const cartItems = useSelector((state) => state.cart);

//   if (!cartItems || cartItems.length === 0) {
//     return <p>Your cart is empty.</p>;
//   }

//   return (
//     <div className="cart-container">
//       {cartItems.map((item) => (
//         <CartItem key={item.id} item={item} />
//       ))}
//     </div>
//   );
// };

// export default Cart;






import React from 'react';
import './Cart.css';
import { useSelector, useDispatch } from 'react-redux';
import { clearCart, removeFromCart, increaseQty, decreaseQty } from '../redux/cartSlice';

const Cart = () => {
  const cartItems = useSelector(state => state.cart.items);
  const dispatch = useDispatch();

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2);

  return (
    <div className="cart-container">
      <h2>Your Cart</h2>
      <button className="clear-btn" onClick={() => dispatch(clearCart())}>Clear Cart</button>

      {cartItems.map(item => (
        <div className="cart-item" key={item.id}>
          <div className="item-info">
            <p className="item-name">{item.title}</p>
            <p className="item-price">${item.price} × {item.quantity}</p>
          </div>

          <div className="item-controls">
            <button onClick={() => dispatch(decreaseQty(item.id))}>−</button>
            <span>{item.quantity}</span>
            <button onClick={() => dispatch(increaseQty(item.id))}>+</button>
            <button className="delete-btn" onClick={() => dispatch(removeFromCart(item.id))}>🗑️</button>
          </div>
        </div>
      ))}

      <div className="cart-total">
        <strong>Total:</strong> ${total}
      </div>

      <button className="checkout-btn">Proceed to Checkout</button>
    </div>
  );
};

export default Cart;
