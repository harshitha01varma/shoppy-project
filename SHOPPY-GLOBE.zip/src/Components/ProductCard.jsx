// import React from "react";
// import { useDispatch } from "react-redux";
// import { addToCart } from "../redux/cartSlice";

// const ProductCard = ({ product }) => {
//   const dispatch = useDispatch();

//   const handleAddToCart = () => {
//     console.log("Adding to cart:", product); // Debug log
//     dispatch(addToCart(product));
//   };

//   return (
//     <div className="product-card">
//       <img src={product.thumbnail} alt={product.title} />
//       <h3>{product.title}</h3>
//       <p>₹{product.price}</p>
//       <button onClick={handleAddToCart}>Add to Cart</button>
//     </div>
//   );
// };

// export default ProductCard;







import React from "react";
import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";


const ProductCard = ({ product }) => {
  const dispatch = useDispatch();

  const handleAddToCart = () => {
    console.log("Adding to cart:", product); // Check if this logs
    dispatch(addToCart(product));
  };

  return (
    <div className="product-card">
      <img src={product.thumbnail} alt={product.title} />
      <h3>{product.title}</h3>
      <p>₹{product.price}</p>
      <button onClick={handleAddToCart}>Add to Cart</button>
    </div>
  );
};

export default ProductCard;



