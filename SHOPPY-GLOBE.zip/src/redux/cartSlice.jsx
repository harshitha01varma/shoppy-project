
// redux/cartSlice.jsx
// import { createSlice } from "@reduxjs/toolkit";

// const cartSlice = createSlice({
//   name: "cart",
//   initialState: [],
//   reducers: {
//     addToCart: (state, action) => {
//       const item = state.find((i) => i.id === action.payload.id);
//       if (item) {
//         item.quantity += 1;
//       } else {
//         state.push({ ...action.payload, quantity: 1 });
//       }
//     },
//     removeFromCart: (state, action) => {
//       return state.filter((item) => item.id !== action.payload);
//     },
//     incrementQty: (state, action) => {
//       const item = state.find((i) => i.id === action.payload);
//       if (item) item.quantity += 1;
//     },
//     decrementQty: (state, action) => {
//       const item = state.find((i) => i.id === action.payload);
//       if (item && item.quantity > 1) item.quantity -= 1;
//     },
//   },
// });

// export const { addToCart, removeFromCart, incrementQty, decrementQty } = cartSlice.actions;
// export default cartSlice.reducer;
// src/redux/cartSlice.js




// import { createSlice } from "@reduxjs/toolkit";

// const cartSlice = createSlice({
//   name: "cart",
//   initialState: [],
//   reducers: {
//     addToCart: (state, action) => {
//       const item = state.find((i) => i.id === action.payload.id);
//       if (item) {
//         item.quantity += 1;
//       } else {
//         state.push({ ...action.payload, quantity: 1 });
//       }
//     },
//     removeFromCart: (state, action) => {
//       return state.filter((item) => item.id !== action.payload);
//     },
//     incrementQty: (state, action) => {
//       const item = state.find((item) => item.id === action.payload);
//       if (item) {
//         item.quantity++;
//       }
//     },
//     decrementQty: (state, action) => {
//       const item = state.find((item) => item.id === action.payload);
//       if (item && item.quantity > 1) {
//         item.quantity--;
//       }
//     }
//   },
// });


// export const { addToCart, removeFromCart, incrementQty, decrementQty } = cartSlice.actions;
// export default cartSlice.reducer;



// import { createSlice } from "@reduxjs/toolkit";

// const cartSlice = createSlice({
//   name: "cart",
//   initialState: [],
//   reducers: {
//     addToCart: (state, action) => {
      
//       console.log("Dispatched action:", action);

//       const item = state.find((i) => i.id === action.payload.id);
//       if (item) {
//         item.quantity += 1;
//       } else {
//         state.push({ ...action.payload, quantity: 1 });
//       }
//     },

//     removeFromCart: (state, action) => {
//       return state.filter((item) => item.id !== action.payload);
//     },

//     incrementQty: (state, action) => {
//       const item = state.find((item) => item.id === action.payload);
//       if (item) {
//         item.quantity++;
//       }
//     },

//     decrementQty: (state, action) => {
//       const item = state.find((item) => item.id === action.payload);
//       if (item && item.quantity > 1) {
//         item.quantity--;
//       }
//     }
//   },
// });
// export const { addToCart, removeFromCart, incrementQty, decrementQty } = cartSlice.actions;
// export default cartSlice.reducer;




// src/redux/cartSlice.jsx
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: [], // array of { id, title, price, quantity }
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const existingItem = state.items.find(item => item.id === action.payload.id);
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        state.items.push({ ...action.payload, quantity: 1 });
      }
    },
    removeFromCart: (state, action) => {
      state.items = state.items.filter(item => item.id !== action.payload);
    },
    increaseQty: (state, action) => {
      const item = state.items.find(item => item.id === action.payload);
      if (item) item.quantity += 1;
    },
    decreaseQty: (state, action) => {
      const item = state.items.find(item => item.id === action.payload);
      if (item && item.quantity > 1) {
        item.quantity -= 1;
      }
    },
    clearCart: (state) => {
      state.items = [];
    },
  },
});

export const {
  addToCart,
  removeFromCart,
  increaseQty,
  decreaseQty,
  clearCart,
} = cartSlice.actions;

export default cartSlice.reducer;


